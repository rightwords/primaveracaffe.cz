<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/*
Plugin Name: Like-Themes Plugins
Description: Requied plugins for CoffeeKing WordPress Themes
Version: 1.6
Author: Like-Themes
Email: support@like-themes.com
License: GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.txt
*/

require_once 'config.php';

require_once 'inc/functions.php';

require_once 'shortcodes/shortcodes.php';

require_once 'post_types/post_types.php';

